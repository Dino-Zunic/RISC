#include "Compiler.hpp"
#include <cstdint>
#include <cstring>

Compiler::Compiler(const std::string& rootFilename) : rootFilename(rootFilename) {}

bool Compiler::compile() {
    Linker linker(rootFilename);
    if (!linker.link()) {
        errors = linker.getErrors();
        return false;
    }
    const auto& commands = linker.getCommands();
    return processCommands(commands);
}

const std::vector<Error>& Compiler::getErrors() const {
    return errors;
}

bool Compiler::hasErrors() const {
    return !errors.empty();
}

const std::vector<uint32_t>& Compiler::getMachineCode() const {
    return machineCode;
}

bool Compiler::generateMachineCode(const Command& cmd, std::vector<uint32_t>& output) {
    uint8_t opcode = LanguageInfo::OPCODE_INVALID;
    uint8_t addrMode = static_cast<uint8_t>(cmd.getAddressMode());

    switch (cmd.getType()) {
    case Command::Type::Instruction: {
        opcode = LanguageInfo::getOpcode(cmd.getName());
        if (opcode == LanguageInfo::OPCODE_INVALID) {
            errors.emplace_back("Invalid opcode for instruction: " + cmd.getName());
            return false;
        }

        switch (cmd.getAddressMode()) {
        case LanguageInfo::AddressMode::RegisterDirect:
        case LanguageInfo::AddressMode::RegisterIndirect:
            // Format: Opcode | AddrMode | Reg1 | Reg2 | Reg3 | Rest Unused
        {
            uint32_t word = 0;
            word |= (opcode << 24);
            word |= (addrMode << 21);
            word |= (cmd.getR1() << 16);
            word |= (cmd.getR2() << 11);
            word |= (cmd.getR3() << 6);
            output.push_back(word);
        }
        break;

        case LanguageInfo::AddressMode::Immediate:
        case LanguageInfo::AddressMode::MemoryDirect:
        case LanguageInfo::AddressMode::RegisterIndirectWithDisplacement:
            // Format: Opcode | AddrMode | Reg1 | Reg2 | Rest Unused
        {
            uint32_t word = 0;
            word |= (opcode << 24);
            word |= (addrMode << 21);
            word |= (cmd.getR1() << 16);
            word |= (cmd.getR2() << 11);
            output.push_back(word);
            // Add 32-bit constant/address/displacement
            uint32_t value = cmd.getNumber();
            output.push_back(value);
        }
        break;

        default:
            errors.emplace_back("Unsupported addressing mode for instruction: " + cmd.getName());
            return false;
        }
        break;
    }

    case Command::Type::Directive:
    {
        if (cmd.getSymbol() == "dd") {
            output.push_back(cmd.getNumber());
        }
        else if (cmd.getSymbol() == "dup") {
            uint32_t value = cmd.getNumber();
            for (uint32_t i = 0; i < cmd.getDupNumber(); ++i) {
                output.push_back(value);
            }
        }
        else {
            errors.emplace_back("Unsupported directive: " + cmd.getName());
            return false;
        }
    }
    break;

    case Command::Type::SymbolDefinition:
    case Command::Type::Label:
        // Ignored in compile phase
        break;

    default:
        errors.emplace_back("Unsupported command type: " + cmd.getName());
        return false;
    }

    return true;
}

bool Compiler::processCommands(const std::vector<Command>& commands) {
    machineCode.clear();
    for (const auto& cmd : commands) {
        if (!generateMachineCode(cmd, machineCode)) {
            return false;
        }
    }
    return true;
}
