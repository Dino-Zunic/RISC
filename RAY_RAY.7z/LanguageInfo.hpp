#pragma once

#include <string>
#include <unordered_set>
#include <array>

class LanguageInfo {
public:
    enum class Category : uint8_t {
        Arithmetic1,
        Arithmetic2,
        Arithmetic3,
        LoadStore,
        Jump0,
        Jump1,
        Jump2,
        Count
    };

    enum class AddressMode : uint8_t{
        Immediate = 0b100,
        RegisterDirect = 0b000,
        MemoryDirect = 0b110,
        RegisterIndirect = 0b010,
        RegisterIndirectWithDisplacement = 0b111
    };

    struct Instruction {
        std::string name;
        uint8_t opcode;

        bool operator==(const Instruction& other) const {
            return name == other.name;
        }
    };


    static size_t getRegisterIndex(const std::string& name);
    static uint8_t getOpcode(const std::string& name);

    static bool isInstructionInCategory(const std::string& name, Category category);

    static constexpr size_t REGISTER_INVALID = ~0;
    static constexpr uint8_t OPCODE_INVALID = ~0;

    static const std::unordered_set<std::string> keywords;
private:
    static constexpr size_t CategorySize = static_cast<size_t>(Category::Count);

    static std::string normalize(const std::string& name);
    static const std::array<std::unordered_set<Instruction>, CategorySize> instructionSets;
};
