#pragma once

#include <vector>
#include <string>
#include "Linker.hpp"

class Compiler {
public:
    Compiler(const std::string& rootFilename);

    bool compile();
    const std::vector<Error>& getErrors() const;
    bool hasErrors() const;
    const std::vector<uint32_t>& getMachineCode() const;
private:
    std::string rootFilename;
    std::vector<Error> errors;
    std::vector<uint32_t> machineCode;

    bool generateMachineCode(const Command& cmd, std::vector<uint32_t>& output);
    bool processCommands(const std::vector<Command>& commands);
};
